using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMove : MonoBehaviour
{
    public float Speed = 6.0F;
    public float TurnSpeed = 54.0F;
    private Rigidbody CharcterRb;
    private bool isOnGround = true;
    private bool GameOver = false;
    public float Jump = 8.0F;
 

    // Start is called before the first frame update
    void Start()
    {
        CharcterRb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        movement();
        if (Input.GetKeyDown(KeyCode.Space) && isOnGround == true && !GameOver)
        {
            CharcterRb.AddForce(Vector3.up * Jump, ForceMode.Impulse);
            isOnGround = false;
        }
        //Jumping();
    }


    void movement()
    {
        float VerticalMovement = Input.GetAxis("Horizontal") * TurnSpeed;
        float HorizontalMovement = Input.GetAxis("Vertical") * Speed;
        VerticalMovement *= Time.deltaTime;
        HorizontalMovement *= Time.deltaTime;

        transform.Translate(-HorizontalMovement, 0, 0);
        transform.Rotate(0, VerticalMovement, 0);
    }

    void Jumping()
    {
        if (Input.GetKeyDown(KeyCode.Space) && isOnGround == true && !GameOver)
        {
            CharcterRb.AddForce(Vector3.up * Jump, ForceMode.Impulse);
            isOnGround = false;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.CompareTag("JumpSurface"))
        {
            isOnGround = true;
        }
    }
}
